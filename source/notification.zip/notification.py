import json
import boto3
import os
dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    table = dynamodb.Table(os.environ['tablename'])
    message = json.loads( event['Records'][0]['Sns']['Message'] )
    type = message['notificationType']
    id = message['mail']['messageId']
    time = message['mail']['timestamp']
    source = message['mail']['source']
    sourceip = message['mail']['sourceIp']
    recipient = message['mail']['destination']

    if type == "Delivery":
        table.put_item(
            Item=dict( messageId=id, type=type, timestamp=time, source=source, sourceIp=sourceip, recipient=recipient )
        )

    if type == "Bounce":
        recipient = message['bounce']['bouncedRecipients']
        feedback_id = message['bounce']['feedbackId']
        bounce_time = message['bounce']['timestamp']
        table.put_item(
            Item=dict( messageId=id, type=type, timestamp=time, bounce_timestamp=bounce_time, source=source,
                       sourceIp=sourceip, recipient=recipient, feedbackId=feedback_id )
        )

    if type == "Complaint":
        recipient = message['complaint']['complainedRecipients']
        feedback_id = message['complaint']['feedbackId']
        complaint_time = message['complaint']['timestamp']
        table.put_item(
            Item=dict( messageId=id, type=type, timestamp=time, complaint_time=complaint_time, source=source,
                       sourceIp=sourceip, recipient=recipient, feedbackId=feedback_id )
        )

    return None

